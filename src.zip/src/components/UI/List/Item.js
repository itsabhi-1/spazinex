import React from 'react';

function LI({children}) {
    return (
        <li>
            {children}
        </li>
    );
}

export default LI;